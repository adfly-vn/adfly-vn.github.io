//
//  XBInterActiveAdSDK.h
//  XBInterActiveAdSDK
//
//  Created by 全尼古拉斯 on 2020/7/21.
//  Copyright © 2020 全尼古拉斯. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for XBInterActiveAdSDK.
FOUNDATION_EXPORT double XBInterActiveAdSDKVersionNumber;

//! Project version string for XBInterActiveAdSDK.
FOUNDATION_EXPORT const unsigned char XBInterActiveAdSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XBInterActiveAdSDK/PublicHeader.h>


