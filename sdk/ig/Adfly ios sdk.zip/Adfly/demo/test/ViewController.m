//
//  ViewController.m
//  test
//
//  Created by 全尼古拉斯 on 2020/9/9.
//  Copyright © 2020 全尼古拉斯. All rights reserved.
//

#import "ViewController.h"
#import <XBInterActiveAdSDK/XBInterActiveAdSDK.h>
@interface ViewController ()

@end

@implementation ViewController

//let appKey = "demo"
//let appSecret = "ac4a10da9e7f62adb59dbe7f62adb59dbe770e8d"
//let soltId: Int64 = 1
- (void)viewDidLoad {
    [super viewDidLoad];
    [[XBInterActiveAdManager shared] startWithAppKey:@"demo" appSecret:@"ac4a10da9e7f62adb59dbe7f62adb59dbe770e8d" complete:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self show];
        });
        
    }];
}

- (void)show
{
    
    [[XBInterActiveAdManager shared] showAdWithScale:1 origin:CGPointMake(100, 100) customView:self.view onShowAction:^{
        NSLog(@"Ad show");
    } onClickAction:^{
        NSLog(@"ad clicked");
    } onCloseAction:^{
        NSLog(@"ad close");
    }];
    
}

@end
