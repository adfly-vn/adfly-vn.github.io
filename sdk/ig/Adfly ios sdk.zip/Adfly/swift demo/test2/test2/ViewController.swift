//
//  ViewController.swift
//  test2
//
//  Created by 全尼古拉斯 on 2020/9/9.
//  Copyright © 2020 全尼古拉斯. All rights reserved.
//

import UIKit
import XBInterActiveAdSDK

let appKey = "demo"
let appSecret = "ac4a10da9e7f62adb59dbe7f62adb59dbe770e8d"
let soltId: Int64 = 1
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        XBInterActiveAdManager.shared.start(appKey: appKey, appSecret: appSecret, complete: { (error) in
            if error == nil {
                print("注册成功")
                DispatchQueue.main.async {
                    self.show()
                }
            }
        })
        
    
    }

    func show() {
        
        XBInterActiveAdManager.shared.showAd(scale: 1, customView: self.view, onShowAction: {
            print("广告展示")
        }, onClickAction: {
            print("用户点击")
        }, onCloseAction: {
            print("用户关闭")
        }, onLoadFailed: { (error) in
            print("显示失败")
        })
    }

}

